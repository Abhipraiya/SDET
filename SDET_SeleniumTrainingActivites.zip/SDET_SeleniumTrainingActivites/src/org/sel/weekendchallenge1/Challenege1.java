package org.sel.weekendchallenge1;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;



public class Challenege1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String URL ="https://www.google.com";
	      
		
		System.setProperty("webdriver.gecko.driver","C:\\Kaifi\\SDET_SeleniumTraining\\Driver\\geckodriver.exe");
	    WebDriver driver = new FirefoxDriver();
	   
	    
	    driver.get(URL);
	    
	    WebElement Search = driver.findElement(By.xpath("//input[@name ='q']"));
	    
	    Search.sendKeys("Cheese");
	    //get the Type Text
	    System.out.println("TypeText in Textbox : "+Search.getText());
	    
	    //Click on button
	    //WebElement button = driver.findElement(By.xpath("//input[@name ='btnK']"));
	    //button.click();
	    
	    List<WebElement> Option = driver.findElements(By.xpath("//span[contains(text(),'Cheese')]"));
	    
	   
	    
	    driver.close();
	}

}
