package org.sel.Activity7_1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Activity7_1 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String URL ="https://www.training-support.net/selenium/selects";
	      
		
		System.setProperty("webdriver.gecko.driver","C:\\Kaifi\\SDET_SeleniumTraining\\Driver\\geckodriver.exe");
	    WebDriver driver = new FirefoxDriver();
	    
	    //Navigate to the Url
	    driver.get(URL);
	    
	    //Chosen option
	    WebElement chosen = driver.findElement(By.id("single-value"));
	    
	    //Find dropdown
	    Select dropdown = new Select(driver.findElement(By.xpath("single-select")));
	    
	    //Select second option by visible text
	    dropdown.selectByValue("Option 2");
	    System.out.println(chosen.getText());
	    
        //Select third option by index
		dropdown.selectByIndex(3);
	    System.out.println(chosen.getText());
	    
        //Select fourth option by value
		dropdown.selectByValue("4");
	    System.out.println(chosen.getText());
	    
        //Get all options
		
        List<WebElement> options = dropdown.getOptions();
	
        //Print them
	
        for(WebElement option : options) {
	
            System.out.println("Option: " + option.getText());
	
        }
	
 
	
        //Close browser
	
        driver.close();
	    
	    
	    
	    
	    
	}
}
