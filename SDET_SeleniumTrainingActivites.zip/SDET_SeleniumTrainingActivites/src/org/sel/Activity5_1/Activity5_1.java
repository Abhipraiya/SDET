package org.sel.Activity5_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Activity5_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String URL ="https://www.training-support.net/selenium/dynamic-controls";
      
		
		System.setProperty("webdriver.gecko.driver","C:\\Kaifi\\SDET_SeleniumTraining\\Driver\\geckodriver.exe");
	    WebDriver driver = new FirefoxDriver();
	    
	    //Navigate to the Url
	    driver.get(URL);
	    
	    //Get the title of the page
	    String Title = driver.getTitle();
	    System.out.println("Title of the Page :"+ Title);
	    
        //Find the checkbox
        WebElement checkboxInput = driver.findElement(By.xpath("//input[@type='checkbox']"));
        System.out.println("Checkbox displayed :"+ checkboxInput.isDisplayed());
        
        driver.findElement(By.id("toggleCheckbox")).click();
        
        System.out.println("The checkbox Input is displayed: " + checkboxInput.isDisplayed());
        
	    //driver.wait();
	    
	    
	    
	    driver.close();
	
	}
	

}
