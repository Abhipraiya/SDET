
public class Activity1_1 {

	public static void main(String[] args) {
		Car Innova=new Car();
		
			Innova.make=2020;
			Innova.color="white";
			Innova.transmission="Mannual";
		
			Innova.displayCharacterstics();
			Innova.accelerate();
			Innova.brake();

	}

}
